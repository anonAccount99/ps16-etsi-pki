package eu.fbk.aleph.its.benchmark.etsi103097;

import eu.fbk.aleph.its.config.Setup;
import eu.fbk.aleph.its.domain.denm.transmission.etsi103097.DenmGenerator;
import org.certificateservices.custom.c2x.common.CertStore;
import org.certificateservices.custom.c2x.etsits103097.v131.datastructs.secureddata.EtsiTs103097DataSigned;
import org.certificateservices.custom.c2x.etsits103097.v131.generator.ETSISecuredDataGenerator;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.SampleTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Benchmark)
public class DenmReceiverBenchmark {

    // Benchmark objects
    private DenmGenerator generator;
    private ETSISecuredDataGenerator securedMessageGenerator;
    private CertStore trustStore;
    private CertStore certStore;
    private EtsiTs103097DataSigned sampleMessage;

    @org.openjdk.jmh.annotations.Setup(Level.Trial)
    public void setUp() throws Exception {
        // Initialize setup to get the required components for ETSI 103097
        Setup setup = new Setup();
        setup.init();

        // Get the required components from setup
        this.securedMessageGenerator = Setup.getSecuredMessageGenerator();
        this.trustStore = Setup.getTrustStore();
        this.certStore = Setup.getAuthTicketCertStore();

        // Create generator and sample message for verification benchmarks
        this.generator = new DenmGenerator();
        this.sampleMessage = generator.getDENMessage();
    }

    @Benchmark
    public void verifyMessage(Blackhole bh) throws Exception {
        // Benchmark the complete message verification process
        // This mirrors the core operation of message reception
        securedMessageGenerator.verifySignedData(
                sampleMessage,
                certStore,
                trustStore
        );
        bh.consume(sampleMessage);
    }

    @Benchmark
    public void generateAndVerify(Blackhole bh) throws Exception {
        // Benchmark the complete receive cycle: generation + verification
        // Generate a fresh message for each iteration
        DenmGenerator generator = new DenmGenerator();
        EtsiTs103097DataSigned message = generator.getDENMessage();

        // Verify the message (core reception operation)
        securedMessageGenerator.verifySignedData(
                message,
                certStore,
                trustStore
        );

        bh.consume(message);
    }
}
