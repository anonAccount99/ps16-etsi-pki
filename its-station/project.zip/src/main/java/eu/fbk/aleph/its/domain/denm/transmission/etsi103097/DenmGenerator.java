package eu.fbk.aleph.its.domain.denm.transmission.etsi103097;

import eu.fbk.aleph.its.config.Setup;
import eu.fbk.aleph.its.domain.authorization.AuthorizationCredentials;
import org.bouncycastle.util.encoders.Hex;
import org.certificateservices.custom.c2x.common.BadArgumentException;
import org.certificateservices.custom.c2x.etsits103097.v131.datastructs.secureddata.EtsiTs103097DataSigned;
import org.certificateservices.custom.c2x.etsits103097.v131.generator.ETSISecuredDataGenerator;
import org.certificateservices.custom.c2x.ieee1609dot2.datastructs.basic.ThreeDLocation;
import org.certificateservices.custom.c2x.ieee1609dot2.datastructs.basic.Time64;
import org.jboss.logging.Logger;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Date;


public class DenmGenerator {
    private final Logger LOGGER = Logger.getLogger(DenmGenerator.class);
    private EtsiTs103097DataSigned dENMessage;

    public DenmGenerator() throws IOException, BadArgumentException, NoSuchAlgorithmException, SignatureException {
        ETSISecuredDataGenerator securedMessageGenerator = Setup.getSecuredMessageGenerator();
        AuthorizationCredentials authorizationCredentials = Setup.getAuthorizationCredentials();

        // To generate a Signed DEN Message
        byte[] dENMessageData = Hex.decode("010203040506");
        dENMessage = securedMessageGenerator.genDENMessage(
                new Time64(new Date()), // generationTime
                new ThreeDLocation(1,2,3), // generationLocation
                dENMessageData, // inner opaque DEN message data
                authorizationCredentials.getAuthorizationTicket(), // signerCertificate
                authorizationCredentials.getAuthTicketSignKeys().getPrivate()); // signerPrivateKey

        LOGGER.info("Generated denm message " + dENMessage.toString());

    }
    public EtsiTs103097DataSigned getDENMessage() {
        return dENMessage;
    }
}
