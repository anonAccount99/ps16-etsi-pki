package eu.fbk.aleph.its;

import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import java.util.logging.Logger;

public class Main {
    static Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        try {
            Options opt = new OptionsBuilder()
                    .include(eu.fbk.aleph.its.benchmark.groupsig.DenmGeneratorBenchmark.class.getSimpleName())
                    .include(eu.fbk.aleph.its.benchmark.groupsig.DenmReceiverBenchmark.class.getSimpleName())
                    .include(eu.fbk.aleph.its.benchmark.etsi103097.DenmGeneratorBenchmark.class.getSimpleName())
                    .include(eu.fbk.aleph.its.benchmark.etsi103097.DenmReceiverBenchmark.class.getSimpleName())
                    .forks(3)
                    .warmupIterations(10)
                    .measurementIterations(20)
                    .jvmArgs("-Xms2G", "-Xmx2G")
                    .build();

            new Runner(opt).run().forEach(r ->
                logger.info("Benchmark result: " + r.getPrimaryResult().getScore() + " " + r.getPrimaryResult().getScoreUnit())
            );
        } catch (Exception e) {
            logger.severe("Failed to run benchmark: " + e.getMessage());
            System.exit(1);
        }
    }
}