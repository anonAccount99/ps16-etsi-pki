package eu.fbk.aleph.its.benchmark.etsi103097;

import eu.fbk.aleph.its.config.Setup;
import eu.fbk.aleph.its.domain.denm.transmission.etsi103097.DenmGenerator;
import eu.fbk.aleph.its.domain.denm.transmission.etsi103097.DenmTransmitter;
import org.certificateservices.custom.c2x.etsits103097.v131.datastructs.secureddata.EtsiTs103097DataSigned;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.SampleTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Benchmark)
public class DenmGeneratorBenchmark {

    // Benchmark objects
    private DenmGenerator generator;
    private DenmTransmitter transmitter;
    private String actionId;

    @org.openjdk.jmh.annotations.Setup(Level.Trial)
    public void setUp() throws Exception {
        // Initialize setup to get the required components for ETSI 103097
        Setup setup = new Setup();
        setup.init();

        // Create benchmark objects - ETSI 103097 version uses simple constructors
        this.generator = new DenmGenerator();
        this.transmitter = new DenmTransmitter();
        this.actionId = "benchmark-action-" + System.currentTimeMillis();
    }

    @Benchmark
    public void generateAndTransmit(Blackhole bh) throws Exception {
        // Benchmark the complete generation, signing, and transmission cycle
        // Create a new generator for each benchmark iteration to ensure fresh messages
        DenmGenerator generator = new DenmGenerator();
        EtsiTs103097DataSigned message = generator.getDENMessage();
        byte[] encoded = message.getEncoded();

        // Simulate the transmission by consuming the encoded payload
        bh.consume(encoded);
        bh.consume(message);
    }

    @TearDown(Level.Trial)
    public void tearDown() {
        // Clean up any pending transmissions
        if (transmitter != null) {
            transmitter.cancelEvent(actionId);
        }
    }
}